import {FiLoader} from "react-icons/fi"

export const Loader = () => {
    return (
        <div className="laoding-animation">
            <FiLoader className="w-6 h-6"/>
        </div>
    )
}
