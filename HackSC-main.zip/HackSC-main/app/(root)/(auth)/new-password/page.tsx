import {NewPasswordForm} from "../_components/new-password-form"

const NewPasswordPage = () => {
    return (
        <section className="w-full">
            <NewPasswordForm/>
        </section>
    )
}

export default NewPasswordPage
