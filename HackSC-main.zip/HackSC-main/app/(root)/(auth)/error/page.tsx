"use client"

import {ErrorCard} from "@/components/shared/error-card"

const AuthErrorPage = () => {
    return (
        <section>
            <ErrorCard/>
        </section>
    )
}

export default AuthErrorPage
