import {NewVerificationForm} from "../_components/new-verification-form"

const NewVerificationPage = () => {
    return (
        <section className="w-full">
            <NewVerificationForm/>
        </section>
    )
}

export default NewVerificationPage
