import {SignUpForm} from "../_components/signup-form"

const SignUpPage = () => {
    return (
        <section
            className="w-full"
        >
            <SignUpForm/>
        </section>
    );
}

export default SignUpPage
