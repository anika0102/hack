import {ResetForm} from "../_components/reset-form"

const ResetPage = () => {
    return (
        <section className="w-full">
            <ResetForm/>
        </section>
    )
}

export default ResetPage
