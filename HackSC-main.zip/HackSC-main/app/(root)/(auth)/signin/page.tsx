import {SignInForm} from "../_components/signin-form"

const SignInPage = () => {
    return (
        <section className="w-full">
            <SignInForm/>
        </section>
    )
}

export default SignInPage
